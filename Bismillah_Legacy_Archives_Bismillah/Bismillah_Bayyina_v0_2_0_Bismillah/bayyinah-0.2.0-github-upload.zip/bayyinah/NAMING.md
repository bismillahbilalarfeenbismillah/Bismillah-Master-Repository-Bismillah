# Bayyinah — Naming Discipline

**Status:** Draft 1. See "Open questions" at the bottom.

---

## Purpose

This document is the standing discipline for how Bayyinah draws on Qur'anic and classical Islamic scholarly vocabulary in code. It exists so that (a) the naming stays coherent as the project grows, (b) contributors understand *why* certain names are chosen and others are avoided, and (c) the reverence is layered correctly — no decorative sprinkling, no trivialization.

---

## The core principle

**Surahs name seasons. Classical scholarly methodology names modules.**

Development *phases* are temporal — they have a beginning, an energy, and an end. Naming a phase after a surah ("the al-Kawthar pass") describes the quality of that season of work without claiming the phase *is* the surah. That framing was already in the competition roadmap and it works.

Code *modules*, by contrast, are persistent artifacts. They sit in the repo, get imported by name, show up in stack traces, get published on PyPI. Putting a surah name on a Python class would either flatten the surah or elevate the class; neither is appropriate. Modules should instead draw from the methodological vocabulary of classical Islamic scholarship — tafsir, usul al-fiqh, ilm al-hadith — where the terms are precisely the kind of mundane technical language designed to be used in working analysis.

This is the same distinction that kept Islamic scholarship coherent for a thousand years: reverence for the text, rigor in the method. We apply it to code.

---

## Top-level naming

**Project name: `Bayyinah`** (Surah 98, "The Clear Evidence").

The *project* aspires to be clear evidence of file integrity. This is an aspirational, outward-facing name, and Surah 98's theme — distinguishing the clear from the obscure — is the theological spine of the project. This is appropriate for the repository name and for the top-level `ScanService` instance. Individual code artifacts inside should not themselves claim the name.

**Theoretical grounding: Munafiq Protocol** (DOI: 10.5281/zenodo.19677111).

Already established. Bayyinah applies Section 9 of the Munafiq Protocol (performed-alignment detection at the input layer) to data rather than to agents.

---

## Scanning layer names

The two-layer structure is already in `bayyinah_v0_1.py` as `TextLayerAnalyzer` and `ObjectLayerAnalyzer`. The proposal is to rename them using the tafsir distinction between apparent and inner meaning, which is a near-exact mapping of what the layers actually do.

**`ZahirAnalyzer`** — *zahir* (ظاهر) means the apparent, outer, manifest layer of a text. In tafsir it names the literal surface meaning. In Bayyinah it names the analyzer that reads what the file *renders* — what a human opening the PDF would see. Maps 1:1 to the current `TextLayerAnalyzer`.

**`BatinAnalyzer`** — *batin* (باطن) means the inner, hidden layer. Its tafsir counterpart to zahir. In Bayyinah it names the analyzer that reads what the file *contains* — the object tree, the incremental updates, the embedded streams. Maps 1:1 to the current `ObjectLayerAnalyzer`.

*Note on sectarian history:* the *batini* tradition of esoteric interpretation has specific associations in Islamic history, but zahir/batin as a methodological pair is entirely standard across Sunni and Shi'a tafsir. We are using the methodological pair, not invoking any particular school.

---

## Per-mechanism analyzers (inside `BatinAnalyzer`)

When we do the per-mechanism split deferred from today's refactor, these are the proposed names:

**`NaskhAnalyzer`** — *naskh* (نسخ) is the usul al-fiqh concept of abrogation: a later ruling supersedes an earlier one, but the earlier text remains present in the corpus. This is structurally identical to what happens in a PDF with incremental updates — the later revision supersedes the earlier, but the earlier objects remain in the byte stream. A forensic naskh analysis asks: what was superseded, and does anything downstream still reference it? That is exactly the question the incremental-update detector asks of a PDF. Excellent fit; not theologically elevated (naskh is a technical legal-hermeneutic term, used daily by working scholars).

**`KitmanAnalyzer`** — *kitman* (كتمان) means the deliberate concealment of truth. It appears in the Qur'an as a vice to be named and rejected ("and do not conceal testimony" — Baqarah 2:283). Proposed fit: the analyzer that detects intentional concealment patterns — invisible text, color-matched fonts, zero-opacity overlays, steganographic embedding. We are naming the *detector of the vice*, not endorsing the vice, which is consistent with how the term functions in ethical discourse.

**`TahqiqValidator`** — *tahqiq* (تحقيق) means verification, authentication, critical investigation. Standard classical scholarly term; Ibn Taymiyya and al-Ghazali both use it routinely. Good fit for the cross-check layer that validates findings across independent signals (e.g., confirming that a ZWSP detection in the fitz text matches a raw-stream Unicode hit).

Further per-mechanism analyzers (homoglyph detection, bidi control, ToUnicode CMap, overlay/stacked text) can keep their current English names for now, or receive methodological names as the split proceeds. No need to name them all up front.

---

## Supporting infrastructure names

**`IsnadTracer`** — *isnad* (إسناد) is the chain of transmission in hadith science: the list of narrators through whom a report reached us, each link's reliability assessed independently, breaks flagged. This is the single most perfect mapping in the whole scheme: isnad methodology *is* file provenance analysis, separated only by a thousand years. A provenance layer that records "this finding was derived from fitz's text extraction, confirmed by raw-stream regex, cross-checked against pypdf's content stream" is a literal isnad. Strong recommendation to keep this name when we build the provenance layer.

**Scoring** — *tentative: `MizanScorer`, but I'm uncertain.* Mizan (ميزان) means scale, balance; it is also the Qur'anic name of the Balance of the Day of Judgment (Surah al-Rahman, al-Anbiya, al-A'raf). Putting that name on a Python function that computes `1.0 - sum(sev * conf)` may be too heavy. An alternative is *muwazana* (موازنة) — "weighing, comparative assessment" — which is a mundane scholarly term with no eschatological weight. So: `MuwazanaScorer` or keep plain English (`WeighingScorer` / `IntegrityScorer`). Flagged for discussion.

**Verdict logic** — *tentative.* Similar concern to Mizan. *Furqan* (فرقان) means "the criterion" and is used as an epithet for the Qur'an itself (Surah 25). Too heavy for a Python module. Alternative: *tamyiz* (تمييز) — "discrimination, distinction, separating one thing from another" — a standard scholarly term used for the cognitive act of distinguishing cases. So: `TamyizLogic` or plain `VerdictLogic`. Flagged for discussion.

---

## Development phases (sketch — to refine)

Following the pattern of the competition roadmap's "energy of surah X" framing, Bayyinah's development phases could be:

*Pass 1 — al-'Alaq energy.* Read and recite. Raw ingestion: pull every content layer out of every supported format, build the library, see what's there. (This is what v0 and v0.1 were.)

*Pass 2 — al-Kawthar energy.* Abundance. Cover every mechanism: finish the per-mechanism split, close detection gaps identified in the EOD note, extend to DOCX and HTML.

*Pass 3 — al-Zilzal energy.* The earthquake. Stress-test the whole stack: labeled benign/adversarial corpus, precision/recall measurement, shake out false positives, performance hot-path work. Everything that was standing but untested gets shaken.

*Pass 4 — al-Bayyinah energy.* Clear evidence. Final hardening, reproducible-output fix, pytest golden fixtures, packaging, companion preprint tying back to the Munafiq Protocol. The project becomes what it's named.

This is a sketch; the actual phase structure should be whatever fits the work. The *discipline* — that phases carry surah energy while modules carry methodological names — is the load-bearing part.

---

## Terms to avoid and why

**`Taqiyya`** — means dissimulation of faith under duress; specific theological term primarily associated with Shia practice and repeatedly weaponized in Islamophobic discourse. Even though it superficially fits "concealment detection," *kitman* serves better and carries none of that charge. Do not use.

**`Shirk`** / **`Kufr`** / **Divine Names** — categories of the gravest theological weight. Never appropriate on code.

**`Fitnah`** — trial, tribulation, sedition. Too theologically and historically charged for forensic tooling.

**`Haram` / `Halal`** — religious-ruling terms, not fitting for binary scanner verdicts. A file is malicious or benign, not halal or haram.

**Surah names on persistent code artifacts** — `al_fatiha.py`, `class YaSinAnalyzer`. Do not. Surahs belong on phases, not files.

**The name of the Qur'an itself, Names of prophets, Names of Allah** — obviously never.

---

## Guidance for future contributors

Before proposing a new Qur'anic/scholarly name for a module, ask:

1. Is this term a methodological technical term in classical Islamic scholarship, or is it a name of something sacred? If the latter, do not use it.
2. Does the term name a *method* or a *vice-to-be-detected*? Both are fine. It should not name a virtue in a way that claims the code *embodies* that virtue.
3. Has the term been sectarianly weaponized or Islamophobically distorted in modern discourse? If yes, prefer an adjacent less-charged term.
4. Would a classical scholar find the mapping precise, or cute? We want precise.

When in doubt, use plain English. A `VerdictLogic` is better than a miscast Qur'anic name.

---

## Open questions (for our revision pass)

1. **`MizanScorer` vs `MuwazanaScorer` vs plain `IntegrityScorer`.** I lean away from Mizan; what's your read?
2. **`FurqanLogic` vs `TamyizLogic` vs plain `VerdictLogic`.** Same question.
3. **Should `Bayyinah` appear as a class name anywhere inside the codebase, or strictly as the project/top-level container?** I lean strictly top-level.
4. **`KitmanAnalyzer`** — you know the theological charge of this term better than I do. Comfortable with it as the intentional-concealment detector, or prefer a plain English name?
5. **The phase sketch above** — does it match your intended arc for Bayyinah, or do you have a different season-mapping in mind?
6. **Is there value in a companion short-form: `BAYYINAH_LEXICON.md`** that just lists each scholarly term with its Arabic, transliteration, one-line definition, and the citation for where it's standardly used in the classical tradition? So contributors have a quick reference.

Let's go through these together.
