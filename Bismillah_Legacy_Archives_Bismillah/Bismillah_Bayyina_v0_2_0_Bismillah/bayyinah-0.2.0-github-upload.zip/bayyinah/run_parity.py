#!/usr/bin/env python3
"""
Parity regression harness: bayyinah_v0 vs bayyinah_v0_1.

Runs both scanners against the same PDF corpus and diffs their IntegrityReport
output. The pass condition is byte-identical JSON for every file. Any divergence
is reported with root-cause detail so we can decide whether to fix v0.1 or
whether the divergence is intentional.

Usage:
    python3 run_parity.py
"""

from __future__ import annotations

import json
import re
import sys
import time
import traceback
from dataclasses import asdict, is_dataclass
from pathlib import Path

# pypdf's IndirectObject.__repr__ embeds the python id() of the parent PDF
# document, which changes between allocations. Two back-to-back runs of the
# SAME scanner on the SAME file are not byte-identical for this reason.
# We normalize this pypdf-specific noise out of finding text before comparing.
INDIRECT_OBJ_RE = re.compile(r"IndirectObject\((\d+),\s*(\d+),\s*\d+\)")


def _normalize(value):
    if isinstance(value, str):
        return INDIRECT_OBJ_RE.sub(r"IndirectObject(\1, \2, <id>)", value)
    if isinstance(value, list):
        return [_normalize(v) for v in value]
    if isinstance(value, dict):
        return {k: _normalize(v) for k, v in value.items()}
    return value

BAYYINAH_DIR = Path("/sessions/peaceful-vibrant-babbage/mnt/Bayyinah")
sys.path.insert(0, str(BAYYINAH_DIR))

import bayyinah_v0  # noqa: E402
import bayyinah_v0_1  # noqa: E402


OUT_DIR = Path("/sessions/peaceful-vibrant-babbage/mnt/outputs")
CORPUS_ROOTS = [
    # crafted positive control
    BAYYINAH_DIR / "positive_test.pdf",
    BAYYINAH_DIR / "The_Differentiator_Framework.pdf",
    # Akira (Akira OCR down-tier calibration corpus)
    OUT_DIR / "akira_corpus" / "Akira Book 01.pdf",
    OUT_DIR / "akira_corpus" / "Akira Book 02.pdf",
    OUT_DIR / "akira_corpus" / "Akira_Book_01_Analysis.pdf",
    OUT_DIR / "akira_corpus" / "Akira_Book5_Analysis.pdf",
    # Nausicaä (8-file baseline)
    OUT_DIR / "nausicaa_corpus" / "Volume 1" / "Naus-V1-A.pdf",
    OUT_DIR / "nausicaa_corpus" / "Volume 1" / "Naus-V1-B.pdf",
    OUT_DIR / "nausicaa_corpus" / "Volume 1" / "Naus-V1-C.pdf",
    OUT_DIR / "nausicaa_corpus" / "Volume 1" / "Naus-V1-D.pdf",
    OUT_DIR / "nausicaa_corpus" / "Volume 2" / "Naus-V2-A.pdf",
    OUT_DIR / "nausicaa_corpus" / "Volume 2" / "Naus-V2-B.pdf",
    OUT_DIR / "nausicaa_corpus" / "Volume 2" / "Naus-V2-C.pdf",
    OUT_DIR / "nausicaa_corpus" / "Volume 2" / "Naus-V2-D.pdf",
    # AIGuardPDF (adversarial commercial sample)
    OUT_DIR / "advcorpus" / "AIGuardPDF sample-PDF.pdf",
    # PDF 2.0 examples (structural edge cases)
    OUT_DIR / "advcorpus" / "pdf20examples-master" / "Simple PDF 2.0 file.pdf",
    OUT_DIR / "advcorpus" / "pdf20examples-master" / "PDF 2.0 with offset start.pdf",
    OUT_DIR / "advcorpus" / "pdf20examples-master" / "pdf20-utf8-test.pdf",
    # silent-scan_error wild samples (these exercise the pypdf-open-fail path)
    OUT_DIR / "advcorpus" / "malicious_generated" / "test1.pdf",
    OUT_DIR / "advcorpus" / "malicious_generated" / "test1_1.pdf",
    OUT_DIR / "advcorpus" / "malicious_generated" / "test3.pdf",
    OUT_DIR / "advcorpus" / "malicious_generated" / "test10.pdf",
    OUT_DIR / "advcorpus" / "malicious_generated" / "test15.pdf",
    OUT_DIR / "advcorpus" / "malicious_generated" / "test17.pdf",
    OUT_DIR / "advcorpus" / "malicious_generated" / "test28.pdf",
    OUT_DIR / "advcorpus" / "malicious_generated" / "test29.pdf",
]


def report_to_json(report) -> dict:
    """Normalize an IntegrityReport to a plain dict we can diff."""
    if hasattr(report, "to_dict"):
        d = report.to_dict()
    elif is_dataclass(report):
        d = asdict(report)
    else:
        raise TypeError(f"Don't know how to serialize {type(report)}")
    return _normalize(d)


def findings_shape(findings: list[dict]) -> list[tuple]:
    """Reduce a finding list to a tuple of key fields so we can diff order+content."""
    return [
        (
            f.get("mechanism"),
            f.get("tier"),
            f.get("severity"),
            f.get("confidence"),
            f.get("location"),
        )
        for f in findings
    ]


def diff_reports(a: dict, b: dict) -> list[str]:
    """Return a list of human-readable diff lines. Empty list == byte-identical."""
    diffs = []
    top_keys = set(a.keys()) | set(b.keys())
    for k in sorted(top_keys):
        if k == "findings":
            continue
        if a.get(k) != b.get(k):
            diffs.append(f"  [{k}] v0={a.get(k)!r}  v0.1={b.get(k)!r}")

    fa = a.get("findings", [])
    fb = b.get("findings", [])
    if len(fa) != len(fb):
        diffs.append(f"  [findings.count] v0={len(fa)}  v0.1={len(fb)}")

    sa = findings_shape(fa)
    sb = findings_shape(fb)
    if sa != sb:
        # find the first index where they diverge
        for i, (x, y) in enumerate(zip(sa, sb)):
            if x != y:
                diffs.append(f"  [findings.shape[{i}]] v0={x}  v0.1={y}")
                break
        if len(sa) != len(sb):
            diffs.append(f"  [findings.shape.tail] v0_extra={sa[len(sb):]} v0.1_extra={sb[len(sa):]}")

    # deep equality on every finding to catch description/surface/concealed drift
    for i, (fa_i, fb_i) in enumerate(zip(fa, fb)):
        if fa_i != fb_i:
            for fk in set(fa_i.keys()) | set(fb_i.keys()):
                if fa_i.get(fk) != fb_i.get(fk):
                    diffs.append(
                        f"  [findings[{i}].{fk}] v0={fa_i.get(fk)!r}  v0.1={fb_i.get(fk)!r}"
                    )
    return diffs


def run_one(path: Path) -> dict:
    """Run both scanners against one file and return result metadata."""
    result = {
        "path": str(path),
        "exists": path.exists(),
        "v0_error": None,
        "v01_error": None,
        "v0_time": 0.0,
        "v01_time": 0.0,
        "diffs": [],
        "identical": False,
    }
    if not path.exists():
        result["diffs"] = ["FILE_NOT_FOUND"]
        return result

    try:
        t0 = time.perf_counter()
        r0 = bayyinah_v0.scan_pdf(path)
        result["v0_time"] = time.perf_counter() - t0
        d0 = report_to_json(r0)
    except Exception as e:
        result["v0_error"] = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
        return result

    try:
        t0 = time.perf_counter()
        r1 = bayyinah_v0_1.scan_pdf(path)
        result["v01_time"] = time.perf_counter() - t0
        d1 = report_to_json(r1)
    except Exception as e:
        result["v01_error"] = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
        return result

    diffs = diff_reports(d0, d1)
    result["diffs"] = diffs
    result["identical"] = len(diffs) == 0
    if not result["identical"]:
        result["v0_score"] = d0.get("integrity_score")
        result["v01_score"] = d1.get("integrity_score")
        result["v0_finding_count"] = len(d0.get("findings", []))
        result["v01_finding_count"] = len(d1.get("findings", []))
    return result


def main() -> int:
    # Optional filter: passing a substring on the CLI selects matching files only.
    # Useful to run fast files first, or isolate one corpus slice.
    corpus = CORPUS_ROOTS
    if len(sys.argv) > 1:
        needle = sys.argv[1]
        corpus = [p for p in corpus if needle.lower() in str(p).lower()]
        print(f"Filter {needle!r}: selecting {len(corpus)} files")

    print(f"bayyinah_v0   module: {bayyinah_v0.__file__}")
    print(f"bayyinah_v0_1 module: {bayyinah_v0_1.__file__}")
    print(f"Corpus size: {len(corpus)} files")
    print("=" * 80)

    results = []
    pass_count = 0
    skip_count = 0
    fail_count = 0
    for p in corpus:
        res = run_one(p)
        results.append(res)
        label = p.name
        if res["diffs"] == ["FILE_NOT_FOUND"]:
            print(f"  SKIP  {label}  (not found)")
            skip_count += 1
            continue
        if res["v0_error"] or res["v01_error"]:
            print(f"  FAIL  {label}  (scanner raised)")
            fail_count += 1
            continue
        if res["identical"]:
            print(
                f"  PASS  {label}  "
                f"(v0={res['v0_time']*1000:.0f}ms v0.1={res['v01_time']*1000:.0f}ms)"
            )
            pass_count += 1
        else:
            print(f"  DIFF  {label}")
            for line in res["diffs"][:12]:
                print(line)
            if len(res["diffs"]) > 12:
                print(f"  ... ({len(res['diffs']) - 12} more diff lines)")
            fail_count += 1

    print("=" * 80)
    print(f"PASS={pass_count}  DIFF/FAIL={fail_count}  SKIP={skip_count}")

    # write a full JSON report for later inspection
    json_out = OUT_DIR / "parity_report.json"
    json_out.write_text(json.dumps(results, indent=2, default=str))
    print(f"Full report: {json_out}")

    return 0 if fail_count == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
