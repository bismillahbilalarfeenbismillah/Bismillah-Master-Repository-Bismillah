"""
Bayyinah analyzers package — the middle-community layer (Al-Baqarah 2:143).

Every analyzer inherits a uniform contract (``BaseAnalyzer``) and is
composed by a uniform registry (``AnalyzerRegistry``). That is the whole
package. Concrete analyzers for text and object layers arrive in later
phases; Phase 2 establishes only the contract and the composer.

Additive-only: nothing in this package is imported by
``bayyinah_v0.py`` or ``bayyinah_v0_1.py``. They continue to use their
own internal BaseAnalyzer / ScanService.
"""

from __future__ import annotations

from analyzers.base import BaseAnalyzer
from analyzers.registry import (
    AnalyzerRegistrationError,
    AnalyzerRegistry,
    registered,
)
from analyzers.object_analyzer import BatinObjectAnalyzer
from analyzers.text_analyzer import ZahirTextAnalyzer

__all__ = [
    "BaseAnalyzer",
    "AnalyzerRegistry",
    "AnalyzerRegistrationError",
    "registered",
    "ZahirTextAnalyzer",
    "BatinObjectAnalyzer",
]
