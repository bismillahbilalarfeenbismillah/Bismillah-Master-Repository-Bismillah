"""
ScanService — the orchestrator that makes no distinction between witnesses
(Al-Baqarah 2:285).

    لَا نُفَرِّقُ بَيْنَ أَحَدٍ مِّن رُّسُلِهِۦ
    "We make no distinction between any of His messengers."

The architectural reading: the orchestrator treats every analyzer's
findings equally. No analyzer's output is privileged, reweighted, or
silenced. The service composes them in registration order, recomputes
one APS-continuous score over the merged list, and clamps that score
to SCAN_INCOMPLETE_CLAMP (0.5) whenever any witness reports incomplete
coverage — the single integrity guarantee the reader can rely on.

This file is a structural port of ``bayyinah_v0_1.ScanService`` onto
the Phase 2+ contracts:

  * Analyzers are dispatched via ``analyzers.AnalyzerRegistry`` (not a
    raw ``list[BaseAnalyzer]``).
  * The file is opened via ``infrastructure.PDFClient`` (not the legacy
    ``bayyinah_v0_1.PDFContext``) and routed via
    ``infrastructure.FileRouter``.
  * The return type is ``domain.IntegrityReport``.

Byte-identical parity with ``bayyinah_v0_1.scan_pdf`` is preserved on
every Phase 0 fixture:

    1. Missing file  → error="File not found: <path>", score=0.0,
                       scan_incomplete=True, no findings.
    2. pymupdf-open
       failure       → error="Could not open PDF: <pymupdf-message>",
                       score=0.0, scan_incomplete=True, no findings.
    3. Happy path    → analyzers run in registration order
                       (Text → Object). Findings concatenated in order.
                       Score = clamp(1.0 - Σ(sev × conf), 0, 1),
                       clamped to 0.5 iff scan_incomplete.
    4. Per-analyzer
       errors        → joined with "; " at the top-level report.error.

The pymupdf-open error message is extracted from ``PDFParseError.__cause__``
— ``PDFClient`` wraps the underlying exception with its own prefix
(``"pymupdf could not open ..."``), and v0.1 uses the raw pymupdf
message. Unwrapping the cause restores v0.1's exact error string, which
is what the parity harness compares against.

Additive-only: nothing in this module is imported by ``bayyinah_v0``
or ``bayyinah_v0_1``. They continue to use their own
``ScanService`` / ``scan_pdf`` surface; the two pipelines coexist
until a later phase migrates the CLI onto this one.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from analyzers import AnalyzerRegistry, BatinObjectAnalyzer, ZahirTextAnalyzer
from domain import (
    IntegrityReport,
    PDFParseError,
    apply_scan_incomplete_clamp,
    compute_muwazana_score,
)
from infrastructure import FileRouter, PDFClient


# ---------------------------------------------------------------------------
# Default registry factory
# ---------------------------------------------------------------------------

def default_pdf_registry() -> AnalyzerRegistry:
    """Build the shipped default registry for PDF scanning.

    Registration order is deliberately ``ZahirTextAnalyzer`` first,
    ``BatinObjectAnalyzer`` second — which mirrors v0/v0.1's
    ``DEFAULT_PDF_ANALYZERS`` list. The registry preserves registration
    order when composing findings, so the merged ``IntegrityReport``
    carries text-layer findings before object-layer findings: the exact
    order ``bayyinah_v0_1.scan_pdf`` produces.

    This is a factory (not a module-level singleton) because tests
    frequently want independent registries they can clear, reorder, or
    swap. Handing back a fresh registry per call keeps parallel test
    runs from colliding.
    """
    registry = AnalyzerRegistry()
    registry.register(ZahirTextAnalyzer)
    registry.register(BatinObjectAnalyzer)
    return registry


# ---------------------------------------------------------------------------
# ScanService
# ---------------------------------------------------------------------------

class ScanService:
    """Orchestrate a full scan of one PDF through the registered analyzers.

    Construction::

        ScanService()                                   # default registry
        ScanService(registry=my_registry)               # custom analyzers
        ScanService(file_router=MyFileRouter())         # custom routing

    The service is stateless across ``scan`` calls. It holds references
    to a registry and a file router but mutates neither — callers may
    safely share one ``ScanService`` across threads that do not share
    a registry mutation path.

    The public method is ``scan(pdf_path) -> IntegrityReport``. It
    reproduces v0.1's ``scan_pdf`` semantics byte-for-byte on every
    Phase 0 fixture; the Phase 6 parity harness asserts this across the
    full fixture corpus.
    """

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    def __init__(
        self,
        registry: AnalyzerRegistry | None = None,
        file_router: FileRouter | None = None,
    ) -> None:
        """Construct a ScanService.

        Parameters
        ----------
        registry
            Analyzer registry to dispatch to. Defaults to
            ``default_pdf_registry()`` — the shipped two-analyzer
            pipeline (text → object).
        file_router
            File-type detector used to confirm the input is a supported
            kind before dispatching. Defaults to a fresh ``FileRouter``.
            The router is currently informational — v0.1 had no such
            stage, and we do not branch on its verdict — but holding a
            reference keeps the surface ready for multi-kind scanning
            (DOCX, HTML, …) in later phases without breaking this
            constructor.
        """
        self.registry: AnalyzerRegistry = registry or default_pdf_registry()
        self.file_router: FileRouter = file_router or FileRouter()

    # ------------------------------------------------------------------
    # Public scan
    # ------------------------------------------------------------------

    def scan(self, pdf_path: Path) -> IntegrityReport:
        """Produce one merged IntegrityReport for ``pdf_path``.

        Control flow (byte-identical to ``bayyinah_v0_1.ScanService.scan``
        for every Phase 0 fixture):

            1. Coerce to ``Path``.
            2. Short-circuit if the file does not exist. Score = 0.0,
               error = ``"File not found: <path>"``,
               ``scan_incomplete = True``, no findings.
            3. Pre-flight pymupdf via ``PDFClient.fitz``. On failure,
               short-circuit with score = 0.0,
               error = ``"Could not open PDF: <pymupdf-message>"``,
               ``scan_incomplete = True``, no findings. The pymupdf
               message is recovered from ``PDFParseError.__cause__`` so
               the error string matches v0.1 exactly (v0.1 calls
               ``fitz.open`` directly and lets the raw exception
               surface).
            4. Dispatch to the registry. The registry instantiates every
               registered analyzer, composes their reports, applies the
               ``scan_incomplete`` clamp, and returns one merged
               ``IntegrityReport``. We recompute the final score and
               clamp at this layer for defence-in-depth — the assertion
               is that the registry already did it correctly, and we
               verify in tests that the two paths agree.

        The ``file_router`` reference is retained for multi-kind
        dispatch in later phases; in Phase 6 it does not branch scan
        behaviour — routing to the right analyzer set is the caller's
        responsibility via the ``registry`` argument. Using the default
        registry on a non-PDF file produces whatever each analyzer's
        error path would produce, which for the text and object
        analyzers is a ``scan_error`` + incomplete scan — the honest
        signal that the file is out of scope.
        """
        pdf_path = Path(pdf_path)

        # ------------------------------------------------------------------
        # 1. Missing file — short-circuit identically to v0.1.
        # ------------------------------------------------------------------
        if not pdf_path.exists():
            report = IntegrityReport(
                file_path=str(pdf_path),
                integrity_score=0.0,
            )
            report.error = f"File not found: {pdf_path}"
            report.scan_incomplete = True
            return report

        # ------------------------------------------------------------------
        # 2. pymupdf pre-flight — short-circuit identically to v0.1.
        #
        # v0.1 does: `ctx = PDFContext(pdf_path); _ = ctx.fitz`, catching
        # every exception and surfacing it as ``Could not open PDF: <e>``.
        # PDFClient wraps the pymupdf exception in PDFParseError with
        # its own prefix, so we unwrap via __cause__ to recover v0.1's
        # exact error text. If __cause__ is absent (e.g. pymupdf itself
        # raised a PDFParseError we did not wrap), fall back to the
        # PDFParseError string — still informative, still honest about
        # the failure.
        # ------------------------------------------------------------------
        preflight_error: Exception | None = None
        client = PDFClient(pdf_path)
        try:
            try:
                _ = client.fitz
            except PDFParseError as exc:
                preflight_error = exc.__cause__ or exc
            except Exception as exc:  # noqa: BLE001 — mirror v0.1 bare except
                preflight_error = exc
        finally:
            client.close()

        if preflight_error is not None:
            report = IntegrityReport(
                file_path=str(pdf_path),
                integrity_score=0.0,
            )
            report.error = f"Could not open PDF: {preflight_error}"
            report.scan_incomplete = True
            return report

        # ------------------------------------------------------------------
        # 3. Happy path — dispatch to the registry.
        #
        # AnalyzerRegistry.scan_all already implements the composition
        # semantics we need (registration-order findings, "; "-joined
        # per-analyzer errors, scan_incomplete clamp on error or
        # scan_error finding). We let it do the work, then return the
        # report directly — re-computing score/clamp at this layer
        # would duplicate registry logic and risk the two paths drifting.
        # ------------------------------------------------------------------
        merged = self.registry.scan_all(pdf_path)

        # Defence-in-depth: re-assert the invariants. If an older
        # registry in a custom setup forgets the clamp, we enforce it
        # here without reshaping anything else about the report.
        has_scan_error = any(
            f.mechanism == "scan_error" for f in merged.findings
        )
        if merged.error is not None or has_scan_error:
            merged.scan_incomplete = True
        merged.integrity_score = apply_scan_incomplete_clamp(
            merged.integrity_score,
            scan_incomplete=merged.scan_incomplete,
        )
        return merged

    # ------------------------------------------------------------------
    # Dunders
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        analyzer_names = ", ".join(self.registry.names())
        return (
            f"ScanService(registry=[{analyzer_names}], "
            f"file_router={type(self.file_router).__name__})"
        )


__all__ = [
    "ScanService",
    "default_pdf_registry",
]
