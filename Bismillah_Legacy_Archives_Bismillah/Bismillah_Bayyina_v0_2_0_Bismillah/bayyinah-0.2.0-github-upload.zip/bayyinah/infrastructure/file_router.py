"""
FileRouter — each tribe knowing its drinking-place (Al-Baqarah 2:60).

    قَدْ عَلِمَ كُلُّ أُنَاسٍ مَّشْرَبَهُمْ
    "Each tribe knew its drinking-place."

The architectural reading: Bayyinah will eventually accept PDF, DOCX,
HTML, Markdown, JSON, images, and code files. Each needs its own
parser — there is no single "document" extractor. The FileRouter
inspects a file (magic bytes first, extension as a hint, contents
disagreement flagged) and routes it to the right client. Phase 3
implements PDF dispatch; the other file types are classified
correctly but return ``UnsupportedFileType`` when a client is
requested — the signalling is honest about what the scanner can
currently drink from.

The router distinguishes:

    FileKind    — what the file IS, based on bytes + extension
    client_for  — the appropriate adapter, or raises UnsupportedFileType
    detect      — type detection without committing to a client

It also surfaces extension/content mismatches (a ``.pdf`` file whose
bytes are really ZIP is a strong signal in itself — polyglot files
are a known adversarial pattern).
"""

from __future__ import annotations

import enum
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from domain.exceptions import BayyinahError, PDFParseError
from infrastructure.pdf_client import PDFClient


# ---------------------------------------------------------------------------
# Router-specific exceptions
# ---------------------------------------------------------------------------

class UnsupportedFileType(BayyinahError):
    """The file was identified but Bayyinah has no client for it yet.

    Raised by ``FileRouter.client_for`` when asked to open a file whose
    type is recognised but whose parser path is not yet implemented.
    This is distinct from ``PDFParseError`` — the file is not *broken*,
    it is *out of scope*.
    """


class UnknownFileType(BayyinahError):
    """The file's type could not be identified from either magic bytes
    or extension. Distinct from UnsupportedFileType: we do not know
    *what* this file is, not merely that we cannot open it."""


# ---------------------------------------------------------------------------
# FileKind — closed enumeration of every file class Bayyinah recognises
# ---------------------------------------------------------------------------

class FileKind(enum.Enum):
    """File classes Bayyinah is designed to scan.

    This enumeration matches the project scope declared in the Bayyinah
    charter. Values are stable strings suitable for logging and for
    future serialisation — do not renumber.
    """

    PDF = "pdf"
    DOCX = "docx"
    HTML = "html"
    MARKDOWN = "markdown"
    JSON = "json"
    IMAGE_PNG = "image_png"
    IMAGE_JPEG = "image_jpeg"
    CODE = "code"
    UNKNOWN = "unknown"


# ---------------------------------------------------------------------------
# Detection result
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class FileTypeDetection:
    """Result of ``FileRouter.detect``.

    Fields
    ------
    kind
        Best-guess classification of the file.
    reason
        Human-readable explanation of how ``kind`` was determined
        ("PDF magic header at byte 0"; "extension .md with no
        magic-byte signature"; etc.).
    extension_mismatch
        True when the file's bytes indicate a different type than its
        extension would suggest. Polyglot files (.pdf with a ZIP
        header, .png with HTML inside) are a known adversarial pattern
        — callers can surface this as a structural finding without
        loading a parser.
    """

    kind: FileKind
    reason: str
    extension_mismatch: bool = False


# ---------------------------------------------------------------------------
# Detection primitives
# ---------------------------------------------------------------------------

# Magic-byte prefixes, ordered by specificity.
_MAGIC_PREFIXES: list[tuple[bytes, FileKind, str]] = [
    (b"%PDF-",                     FileKind.PDF,        "PDF %PDF- header"),
    (b"\x89PNG\r\n\x1a\n",         FileKind.IMAGE_PNG,  "PNG 8-byte signature"),
    (b"\xff\xd8\xff",              FileKind.IMAGE_JPEG, "JPEG SOI marker"),
]

# Extensions, lower-cased without the leading dot.
_EXT_MAP: dict[str, FileKind] = {
    "pdf":      FileKind.PDF,
    "docx":     FileKind.DOCX,
    "html":     FileKind.HTML,
    "htm":      FileKind.HTML,
    "md":       FileKind.MARKDOWN,
    "markdown": FileKind.MARKDOWN,
    "json":     FileKind.JSON,
    "png":      FileKind.IMAGE_PNG,
    "jpg":      FileKind.IMAGE_JPEG,
    "jpeg":     FileKind.IMAGE_JPEG,
    # Code file extensions that the future code-scanner will consume.
    "py":       FileKind.CODE,
    "js":       FileKind.CODE,
    "ts":       FileKind.CODE,
    "tsx":      FileKind.CODE,
    "jsx":      FileKind.CODE,
    "go":       FileKind.CODE,
    "rs":       FileKind.CODE,
    "java":     FileKind.CODE,
    "c":        FileKind.CODE,
    "cpp":      FileKind.CODE,
    "h":        FileKind.CODE,
    "hpp":      FileKind.CODE,
    "rb":       FileKind.CODE,
    "sh":       FileKind.CODE,
}


def _detect_docx(head: bytes, path: Path) -> bool:
    """DOCX is a ZIP with a specific entry. Heuristic: ZIP magic +
    .docx extension. Full structural validation is the job of the
    future DOCX client; the router only needs to classify."""
    return head.startswith(b"PK\x03\x04") and path.suffix.lower() == ".docx"


def _detect_html(head: bytes) -> bool:
    """HTML by content sniff (case-insensitive)."""
    stripped = head.lstrip().lower()
    return stripped.startswith((b"<!doctype html", b"<html", b"<body", b"<head"))


def _detect_json(head: bytes) -> bool:
    """Try parsing the first ~64 KB as JSON."""
    stripped = head.lstrip()
    if not stripped.startswith((b"{", b"[")):
        return False
    try:
        json.loads(head.decode("utf-8", errors="strict"))
        return True
    except Exception:  # noqa: BLE001 — json/unicode can raise either
        return False


# Extensions that we consider "plain-text family"; a content sniff
# treats these as their declared kind rather than UNKNOWN when no
# magic bytes fire.
_TEXT_FAMILY_KINDS: frozenset[FileKind] = frozenset({
    FileKind.HTML,
    FileKind.MARKDOWN,
    FileKind.JSON,
    FileKind.CODE,
})


# ---------------------------------------------------------------------------
# FileRouter
# ---------------------------------------------------------------------------

class FileRouter:
    """Identify a file's type and return a client for scanning it.

    Detection order (first to fire wins):
        1. Magic bytes at file start (PDF, PNG, JPEG, DOCX-as-ZIP).
        2. Content sniff for HTML / JSON.
        3. File extension.
        4. ``FileKind.UNKNOWN``.

    Extension mismatch is flagged when magic-byte detection disagrees
    with the extension's implied kind. Callers can surface this as an
    integrity signal independent of any parser (a ``.pdf`` that is
    really ZIP is adversarial before a single byte is interpreted).
    """

    # Amount of file head to read for content sniffing. 64 KB is enough
    # for every format we detect; larger reads waste I/O on huge files.
    HEAD_BYTES = 64 * 1024

    # ------------------------------------------------------------------
    # Detection
    # ------------------------------------------------------------------

    def detect(self, path: Path) -> FileTypeDetection:
        """Classify ``path`` without opening any parser.

        Does a single bounded read of the file head. Raises ``OSError``
        subclasses (``FileNotFoundError``, ``PermissionError``, etc.)
        if the path is unreadable — those are programmer errors, not
        Bayyinah errors, and should not be swallowed.
        """
        path = Path(path)
        try:
            with path.open("rb") as fh:
                head = fh.read(self.HEAD_BYTES)
        except FileNotFoundError:
            raise
        except OSError:
            raise

        ext = path.suffix.lower().lstrip(".")
        ext_kind = _EXT_MAP.get(ext, FileKind.UNKNOWN)

        # 1. Magic-byte detection.
        for prefix, kind, reason in _MAGIC_PREFIXES:
            if head.startswith(prefix):
                mismatch = ext_kind is not FileKind.UNKNOWN and ext_kind is not kind
                return FileTypeDetection(
                    kind=kind,
                    reason=reason,
                    extension_mismatch=mismatch,
                )

        # DOCX needs the extension hint to separate it from other ZIPs.
        if _detect_docx(head, path):
            return FileTypeDetection(
                kind=FileKind.DOCX,
                reason="ZIP container with .docx extension",
                extension_mismatch=False,
            )

        # 2. Content sniff for HTML / JSON.
        if _detect_html(head):
            mismatch = ext_kind not in (FileKind.HTML, FileKind.UNKNOWN)
            return FileTypeDetection(
                kind=FileKind.HTML,
                reason="HTML content sniff",
                extension_mismatch=mismatch,
            )

        if _detect_json(head):
            mismatch = ext_kind not in (FileKind.JSON, FileKind.UNKNOWN)
            return FileTypeDetection(
                kind=FileKind.JSON,
                reason="JSON content sniff",
                extension_mismatch=mismatch,
            )

        # 3. Extension-based fall-through for text-family kinds.
        if ext_kind in _TEXT_FAMILY_KINDS:
            return FileTypeDetection(
                kind=ext_kind,
                reason=f"extension .{ext} (no magic signature)",
                extension_mismatch=False,
            )

        # 4. Nothing matched.
        return FileTypeDetection(
            kind=FileKind.UNKNOWN,
            reason=(
                f"no magic signature and unrecognised extension "
                f"{ext or '(none)'!r}"
            ),
            extension_mismatch=False,
        )

    # ------------------------------------------------------------------
    # Client dispatch
    # ------------------------------------------------------------------

    def client_for(self, path: Path) -> PDFClient:
        """Return a ready-to-use client for ``path``.

        Phase 3 only implements the PDF path; every other recognised
        type raises ``UnsupportedFileType`` (honestly saying "we know
        what this is, we just don't scan it yet") and ``UNKNOWN`` raises
        ``UnknownFileType``. Callers should generally ``detect()`` first
        and branch on the result.

        The return type annotation is ``PDFClient`` because that's the
        only concrete client today. When DOCX / HTML clients land, the
        signature will widen to a Union — that is a *widening*, not a
        breaking change, and will be additive for existing callers.
        """
        detection = self.detect(path)

        if detection.kind is FileKind.PDF:
            return PDFClient(path)

        if detection.kind is FileKind.UNKNOWN:
            raise UnknownFileType(
                f"Could not identify {path}: {detection.reason}"
            )

        raise UnsupportedFileType(
            f"{path} identified as {detection.kind.value!r} "
            f"({detection.reason}); no client implemented yet. "
            "Supported kinds in Phase 3: PDF."
        )

    def is_supported(self, path: Path) -> bool:
        """Convenience — True if ``client_for`` would succeed."""
        try:
            self.client_for(path).close()
            return True
        except (UnsupportedFileType, UnknownFileType, PDFParseError):
            return False
        except OSError:
            return False


__all__ = [
    "FileRouter",
    "FileKind",
    "FileTypeDetection",
    "UnsupportedFileType",
    "UnknownFileType",
]
