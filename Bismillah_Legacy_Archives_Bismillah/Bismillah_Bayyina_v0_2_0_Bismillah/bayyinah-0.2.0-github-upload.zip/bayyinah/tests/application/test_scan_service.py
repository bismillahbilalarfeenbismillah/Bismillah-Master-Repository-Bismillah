"""
Tests for application.scan_service.ScanService + default_pdf_registry.

This file is the Phase 6 parity guardrail of the Al-Baqarah refactor:
it asserts that ``ScanService.scan`` produces byte-identical output to
``bayyinah_v0_1.scan_pdf`` on every Phase 0 fixture — every finding,
every error string, every score, every flag.

Coverage targets:
  * default_pdf_registry shape — names, order, class identity
  * ScanService construction — default / custom registry / custom router
  * Happy-path semantics per fixture (clean, text, object, positive_combined)
  * Error paths identical to v0.1:
      - missing file → "File not found: <path>"
      - unreadable bytes → "Could not open PDF: <pymupdf-message>"
      - non-PDF bytes → "Could not open PDF: <pymupdf-message>"
  * scan_incomplete clamp — if any path sets scan_incomplete, score ≤ 0.5
  * Parity sweep against bayyinah_v0_1.scan_pdf — every field matches
    after IndirectObject-id normalisation
  * Additive isolation — ScanService is distinct from v0.1.ScanService
"""

from __future__ import annotations

import re
import subprocess
import sys
from pathlib import Path
from typing import Any

import pytest

import bayyinah_v0_1
from analyzers import AnalyzerRegistry, BatinObjectAnalyzer, ZahirTextAnalyzer
from application import ScanService, default_pdf_registry
from domain import IntegrityReport
from infrastructure import FileRouter

from tests.make_test_documents import FIXTURES, FIXTURES_DIR


# ---------------------------------------------------------------------------
# Fixture regeneration (same pattern as tests/analyzers/test_object_analyzer.py)
# ---------------------------------------------------------------------------

@pytest.fixture(scope="session", autouse=True)
def _ensure_fixtures_built() -> None:
    """If any fixture PDF is missing, regenerate the whole corpus."""
    missing = [fx.out_path for fx in FIXTURES.values() if not fx.out_path.exists()]
    if not missing:
        return
    subprocess.run(
        [sys.executable, "-m", "tests.make_test_documents"],
        check=True,
        cwd=str(FIXTURES_DIR.parent.parent),
    )


CLEAN_PDF = FIXTURES_DIR / "clean.pdf"
TEXT_FIXTURE_DIR = FIXTURES_DIR / "text"
OBJECT_FIXTURE_DIR = FIXTURES_DIR / "object"
POSITIVE_COMBINED = FIXTURES_DIR / "positive_combined.pdf"


# ---------------------------------------------------------------------------
# IndirectObject-repr normalisation — same pattern tests/test_fixtures.py uses.
#
# pypdf's IndirectObject.__repr__ embeds ``id()`` of the parent document,
# which differs between independent pypdf readers. Every parity
# comparison below normalises the id component to keep byte-level
# identity meaningful despite this environmental non-determinism.
# ---------------------------------------------------------------------------

_INDIRECT_RE = re.compile(r"IndirectObject\((\d+),\s*(\d+),\s*\d+\)")


def _normalise(s: str) -> str:
    return _INDIRECT_RE.sub(r"IndirectObject(\1, \2, <id>)", s)


def _finding_tuple(f: Any) -> tuple:
    """Byte-level comparison of a finding's v0.1-equivalent fields."""
    return (
        f.mechanism,
        f.tier,
        round(f.confidence, 6),
        _normalise(f.description),
        _normalise(f.location),
        _normalise(f.surface),
        _normalise(f.concealed),
    )


# ---------------------------------------------------------------------------
# default_pdf_registry
# ---------------------------------------------------------------------------

class TestDefaultPdfRegistry:
    """The shipped default registry factory."""

    def test_returns_analyzer_registry(self) -> None:
        assert isinstance(default_pdf_registry(), AnalyzerRegistry)

    def test_registers_exactly_two_analyzers(self) -> None:
        assert len(default_pdf_registry()) == 2

    def test_registration_order_is_text_then_object(self) -> None:
        """The order matches v0.1's DEFAULT_PDF_ANALYZERS list — text
        findings emit before object findings in the merged report."""
        assert default_pdf_registry().names() == ["text_layer", "object_layer"]

    def test_registers_zahir_text_analyzer(self) -> None:
        registry = default_pdf_registry()
        assert registry.get("text_layer") is ZahirTextAnalyzer

    def test_registers_batin_object_analyzer(self) -> None:
        registry = default_pdf_registry()
        assert registry.get("object_layer") is BatinObjectAnalyzer

    def test_returns_fresh_instance_each_call(self) -> None:
        """Factory, not singleton — tests need independent registries."""
        a = default_pdf_registry()
        b = default_pdf_registry()
        assert a is not b

    def test_fresh_registries_do_not_share_state(self) -> None:
        a = default_pdf_registry()
        a.unregister("text_layer")
        b = default_pdf_registry()
        assert "text_layer" in b
        assert "text_layer" not in a


# ---------------------------------------------------------------------------
# ScanService construction
# ---------------------------------------------------------------------------

class TestScanServiceConstruction:
    def test_no_args_uses_default_registry(self) -> None:
        s = ScanService()
        assert s.registry.names() == ["text_layer", "object_layer"]

    def test_no_args_uses_default_file_router(self) -> None:
        s = ScanService()
        assert isinstance(s.file_router, FileRouter)

    def test_accepts_custom_registry(self) -> None:
        custom = AnalyzerRegistry()
        custom.register(ZahirTextAnalyzer)
        s = ScanService(registry=custom)
        assert s.registry is custom
        assert s.registry.names() == ["text_layer"]

    def test_accepts_custom_file_router(self) -> None:
        router = FileRouter()
        s = ScanService(file_router=router)
        assert s.file_router is router

    def test_empty_registry_is_allowed(self) -> None:
        """An empty registry yields a clean, no-op scan — no findings,
        no errors, score 1.0."""
        empty = AnalyzerRegistry()
        s = ScanService(registry=empty)
        report = s.scan(CLEAN_PDF)
        assert report.findings == []
        assert report.integrity_score == 1.0
        assert report.error is None
        assert report.scan_incomplete is False

    def test_repr_mentions_registered_analyzers(self) -> None:
        s = ScanService()
        r = repr(s)
        assert "ScanService" in r
        assert "text_layer" in r
        assert "object_layer" in r


# ---------------------------------------------------------------------------
# scan() return type
# ---------------------------------------------------------------------------

class TestScanReturnType:
    def test_returns_integrity_report(self) -> None:
        report = ScanService().scan(CLEAN_PDF)
        assert isinstance(report, IntegrityReport)

    def test_accepts_string_path(self) -> None:
        """scan() should coerce strings to Path for caller convenience."""
        report = ScanService().scan(str(CLEAN_PDF))
        assert report.file_path == str(CLEAN_PDF)

    def test_accepts_path_object(self) -> None:
        report = ScanService().scan(CLEAN_PDF)
        assert report.file_path == str(CLEAN_PDF)

    def test_file_path_is_reported_as_string(self) -> None:
        report = ScanService().scan(CLEAN_PDF)
        assert isinstance(report.file_path, str)


# ---------------------------------------------------------------------------
# clean.pdf — the reference standard
# ---------------------------------------------------------------------------

class TestCleanPdf:
    def test_no_findings(self) -> None:
        report = ScanService().scan(CLEAN_PDF)
        assert report.findings == []

    def test_perfect_score(self) -> None:
        report = ScanService().scan(CLEAN_PDF)
        assert report.integrity_score == 1.0

    def test_no_error(self) -> None:
        report = ScanService().scan(CLEAN_PDF)
        assert report.error is None

    def test_not_incomplete(self) -> None:
        report = ScanService().scan(CLEAN_PDF)
        assert report.scan_incomplete is False


# ---------------------------------------------------------------------------
# Error paths
# ---------------------------------------------------------------------------

class TestMissingFile:
    def test_error_message_matches_v01(self, tmp_path: Path) -> None:
        ghost = tmp_path / "does_not_exist.pdf"
        report = ScanService().scan(ghost)
        assert report.error == f"File not found: {ghost}"

    def test_score_is_zero(self, tmp_path: Path) -> None:
        report = ScanService().scan(tmp_path / "ghost.pdf")
        assert report.integrity_score == 0.0

    def test_scan_incomplete(self, tmp_path: Path) -> None:
        report = ScanService().scan(tmp_path / "ghost.pdf")
        assert report.scan_incomplete is True

    def test_no_findings(self, tmp_path: Path) -> None:
        report = ScanService().scan(tmp_path / "ghost.pdf")
        assert report.findings == []

    def test_analyzers_are_not_called(self, tmp_path: Path) -> None:
        """The short-circuit must fire before any analyzer instantiation."""
        called: list[str] = []

        class RecordingAnalyzer:
            name = "recording"
            error_prefix = "Recording"
            source_layer = "zahir"

            def scan(self, pdf_path: Any) -> IntegrityReport:
                called.append(str(pdf_path))
                return IntegrityReport(
                    file_path=str(pdf_path), integrity_score=1.0,
                )

        # We bypass class-level validation by stashing an instance in the
        # registry's internal dict as if it were a class whose () yields it.
        class _ClassLike:
            name = "recording"
            def __call__(self) -> Any:
                return RecordingAnalyzer()

        registry = AnalyzerRegistry()
        registry._registry["recording"] = _ClassLike()  # type: ignore[assignment]
        s = ScanService(registry=registry)
        s.scan(tmp_path / "ghost.pdf")
        assert called == [], f"analyzer was called for a missing file: {called}"

    def test_file_path_reported(self, tmp_path: Path) -> None:
        ghost = tmp_path / "absent.pdf"
        report = ScanService().scan(ghost)
        assert report.file_path == str(ghost)


class TestUnopenablePdf:
    """pymupdf cannot parse the file → same short-circuit as v0.1."""

    def test_non_pdf_bytes_produce_could_not_open_error(
        self, tmp_path: Path,
    ) -> None:
        junk = tmp_path / "junk.pdf"
        junk.write_bytes(b"this is definitely not a PDF file")
        report = ScanService().scan(junk)
        assert report.error is not None
        assert report.error.startswith("Could not open PDF:")

    def test_error_string_matches_v01_byte_for_byte(
        self, tmp_path: Path,
    ) -> None:
        """The error string we produce must equal v0.1's string exactly —
        unwrapping PDFParseError.__cause__ is what makes this work."""
        junk = tmp_path / "not_a_pdf.pdf"
        junk.write_bytes(b"\x00\x00\x00not a pdf at all\x00\x00")
        ours = ScanService().scan(junk)
        theirs = bayyinah_v0_1.scan_pdf(junk)
        assert ours.error == theirs.error

    def test_score_is_zero_on_open_failure(self, tmp_path: Path) -> None:
        junk = tmp_path / "corrupt.pdf"
        junk.write_bytes(b"garbage")
        report = ScanService().scan(junk)
        assert report.integrity_score == 0.0

    def test_scan_incomplete_on_open_failure(self, tmp_path: Path) -> None:
        junk = tmp_path / "corrupt.pdf"
        junk.write_bytes(b"garbage")
        report = ScanService().scan(junk)
        assert report.scan_incomplete is True

    def test_no_findings_on_open_failure(self, tmp_path: Path) -> None:
        """Analyzers must not run when pymupdf pre-flight fails."""
        junk = tmp_path / "corrupt.pdf"
        junk.write_bytes(b"garbage")
        report = ScanService().scan(junk)
        assert report.findings == []


# ---------------------------------------------------------------------------
# Per-fixture happy-path semantics (intent preserved from v0 detector tests)
# ---------------------------------------------------------------------------

# (fixture_name, expected_mechanism_set)
_TEXT_FIXTURE_EXPECTED: dict[str, frozenset[str]] = {
    "text.zero_width":       frozenset({"zero_width_chars"}),
    "text.tag_characters":   frozenset({"tag_chars"}),
    "text.bidi_control":     frozenset({"bidi_control"}),
    "text.homoglyph":        frozenset({"homoglyph"}),
    "text.invisible_render": frozenset({"invisible_render_mode"}),
    "text.microscopic_font": frozenset({"microscopic_font"}),
    "text.white_on_white":   frozenset({"white_on_white_text"}),
    "text.overlapping":      frozenset({"overlapping_text"}),
}

_OBJECT_FIXTURE_EXPECTED: dict[str, frozenset[str]] = {
    "object.embedded_javascript":  frozenset({"javascript", "openaction"}),
    "object.embedded_attachment":  frozenset({"embedded_file"}),
    "object.hidden_ocg":           frozenset({"hidden_ocg"}),
    "object.metadata_injection":   frozenset({"metadata_anomaly"}),
    "object.tounicode_cmap":       frozenset({"tounicode_anomaly"}),
    "object.incremental_update":   frozenset({"incremental_update"}),
    "object.additional_actions":   frozenset({"additional_actions"}),
}


@pytest.mark.parametrize(
    "fixture_name,expected",
    list(_TEXT_FIXTURE_EXPECTED.items()),
    ids=list(_TEXT_FIXTURE_EXPECTED.keys()),
)
def test_text_fixture_fires_expected_mechanisms(
    fixture_name: str, expected: frozenset[str],
) -> None:
    fx = FIXTURES[fixture_name]
    report = ScanService().scan(fx.out_path)
    mechanisms = {f.mechanism for f in report.findings}
    assert mechanisms == expected, (
        f"{fixture_name!r} mechanism mismatch:"
        f"\n  expected: {sorted(expected)}"
        f"\n  got:      {sorted(mechanisms)}"
    )


@pytest.mark.parametrize(
    "fixture_name,expected",
    list(_OBJECT_FIXTURE_EXPECTED.items()),
    ids=list(_OBJECT_FIXTURE_EXPECTED.keys()),
)
def test_object_fixture_fires_expected_mechanisms(
    fixture_name: str, expected: frozenset[str],
) -> None:
    fx = FIXTURES[fixture_name]
    report = ScanService().scan(fx.out_path)
    mechanisms = {f.mechanism for f in report.findings}
    assert mechanisms == expected, (
        f"{fixture_name!r} mechanism mismatch:"
        f"\n  expected: {sorted(expected)}"
        f"\n  got:      {sorted(mechanisms)}"
    )


def test_text_fixtures_have_text_findings_before_object_findings() -> None:
    """Registration order = emission order. On a pure text fixture the
    object analyzer contributes nothing, but on positive_combined (mixed
    text + object) the order matters for byte-level parity with v0.1."""
    report = ScanService().scan(POSITIVE_COMBINED)
    text_idxs = [
        i for i, f in enumerate(report.findings) if f.source_layer == "zahir"
    ]
    batin_idxs = [
        i for i, f in enumerate(report.findings) if f.source_layer == "batin"
    ]
    if text_idxs and batin_idxs:
        assert max(text_idxs) < min(batin_idxs), (
            "text findings must emit before object findings — matches "
            "v0.1 DEFAULT_PDF_ANALYZERS order"
        )


# ---------------------------------------------------------------------------
# Byte-identical parity with bayyinah_v0_1.scan_pdf
# ---------------------------------------------------------------------------

def _all_phase0_fixtures() -> list[Path]:
    pdfs = [CLEAN_PDF]
    pdfs.extend(sorted(TEXT_FIXTURE_DIR.glob("*.pdf")))
    pdfs.extend(sorted(OBJECT_FIXTURE_DIR.glob("*.pdf")))
    if POSITIVE_COMBINED.exists():
        pdfs.append(POSITIVE_COMBINED)
    return [p for p in pdfs if p.exists()]


@pytest.mark.parametrize(
    "pdf_path",
    _all_phase0_fixtures(),
    ids=[p.name for p in _all_phase0_fixtures()],
)
def test_parity_finding_tuples_with_v01_scan_pdf(pdf_path: Path) -> None:
    """For every Phase 0 fixture, ScanService.scan must emit the same
    (mechanism, tier, confidence, description, location, surface,
    concealed) tuples as v0.1.scan_pdf — in the same order."""
    ours = ScanService().scan(pdf_path)
    theirs = bayyinah_v0_1.scan_pdf(pdf_path)

    ours_tuples = [_finding_tuple(f) for f in ours.findings]
    theirs_tuples = [_finding_tuple(f) for f in theirs.findings]

    assert ours_tuples == theirs_tuples, (
        f"\nParity diverged on {pdf_path.name}:"
        f"\n  ours  ({len(ours_tuples)}): {ours_tuples}"
        f"\n  v0.1  ({len(theirs_tuples)}): {theirs_tuples}"
    )


@pytest.mark.parametrize(
    "pdf_path",
    _all_phase0_fixtures(),
    ids=[p.name for p in _all_phase0_fixtures()],
)
def test_parity_integrity_score_with_v01(pdf_path: Path) -> None:
    ours = ScanService().scan(pdf_path)
    theirs = bayyinah_v0_1.scan_pdf(pdf_path)
    assert abs(ours.integrity_score - theirs.integrity_score) < 1e-9, (
        f"{pdf_path.name}: score diverged — "
        f"ours={ours.integrity_score}, v0.1={theirs.integrity_score}"
    )


@pytest.mark.parametrize(
    "pdf_path",
    _all_phase0_fixtures(),
    ids=[p.name for p in _all_phase0_fixtures()],
)
def test_parity_error_with_v01(pdf_path: Path) -> None:
    ours = ScanService().scan(pdf_path)
    theirs = bayyinah_v0_1.scan_pdf(pdf_path)
    assert ours.error == theirs.error, (
        f"{pdf_path.name}: error diverged — "
        f"ours={ours.error!r}, v0.1={theirs.error!r}"
    )


@pytest.mark.parametrize(
    "pdf_path",
    _all_phase0_fixtures(),
    ids=[p.name for p in _all_phase0_fixtures()],
)
def test_parity_scan_incomplete_with_v01(pdf_path: Path) -> None:
    ours = ScanService().scan(pdf_path)
    theirs = bayyinah_v0_1.scan_pdf(pdf_path)
    assert ours.scan_incomplete == theirs.scan_incomplete, (
        f"{pdf_path.name}: scan_incomplete diverged — "
        f"ours={ours.scan_incomplete}, v0.1={theirs.scan_incomplete}"
    )


@pytest.mark.parametrize(
    "pdf_path",
    _all_phase0_fixtures(),
    ids=[p.name for p in _all_phase0_fixtures()],
)
def test_parity_finding_count_with_v01(pdf_path: Path) -> None:
    ours = ScanService().scan(pdf_path)
    theirs = bayyinah_v0_1.scan_pdf(pdf_path)
    assert len(ours.findings) == len(theirs.findings), (
        f"{pdf_path.name}: count diverged — "
        f"ours={len(ours.findings)}, v0.1={len(theirs.findings)}"
    )


def test_parity_missing_file_error(tmp_path: Path) -> None:
    ghost = tmp_path / "does_not_exist.pdf"
    ours = ScanService().scan(ghost)
    theirs = bayyinah_v0_1.scan_pdf(ghost)
    assert ours.error == theirs.error
    assert ours.integrity_score == theirs.integrity_score
    assert ours.scan_incomplete == theirs.scan_incomplete


def test_parity_unopenable_pdf(tmp_path: Path) -> None:
    corrupt = tmp_path / "corrupt.pdf"
    corrupt.write_bytes(b"%PDF-1.4 garbled garbled garbled")
    ours = ScanService().scan(corrupt)
    theirs = bayyinah_v0_1.scan_pdf(corrupt)
    assert ours.error == theirs.error
    assert ours.integrity_score == theirs.integrity_score
    assert ours.scan_incomplete == theirs.scan_incomplete
    assert len(ours.findings) == len(theirs.findings)


# ---------------------------------------------------------------------------
# scan_incomplete clamp (defence-in-depth — registry already clamps)
# ---------------------------------------------------------------------------

class TestScanIncompleteClamp:
    def test_clamp_caps_score_at_half_when_incomplete(
        self, tmp_path: Path,
    ) -> None:
        """If scan_incomplete is set, integrity_score must not exceed 0.5."""
        corrupt = tmp_path / "corrupt.pdf"
        corrupt.write_bytes(b"broken")
        report = ScanService().scan(corrupt)
        assert report.scan_incomplete is True
        assert report.integrity_score <= 0.5

    def test_no_clamp_when_scan_is_complete(self) -> None:
        """On clean.pdf the score is 1.0, not clamped — scan_incomplete
        is false, so the clamp must not fire."""
        report = ScanService().scan(CLEAN_PDF)
        assert report.scan_incomplete is False
        assert report.integrity_score == 1.0

    def test_clamp_fires_when_analyzer_emits_scan_error(
        self, tmp_path: Path,
    ) -> None:
        """A scan_error finding by itself (no report.error) still sets
        scan_incomplete and triggers the clamp."""
        # Construct a minimal registry whose only analyzer emits a
        # scan_error but no top-level error. The clamp must still fire.
        from domain import Finding
        from analyzers.base import BaseAnalyzer

        class ScanErrorAnalyzer(BaseAnalyzer):
            name = "scan_error_only"
            error_prefix = "Scan error only"
            source_layer = "batin"

            def scan(self, pdf_path: Any) -> IntegrityReport:
                return IntegrityReport(
                    file_path=str(pdf_path),
                    integrity_score=1.0,
                    findings=[Finding(
                        mechanism="scan_error",
                        tier=3, confidence=0.5,
                        description="simulated", location="document",
                        surface="(skipped)", concealed="simulated",
                        source_layer="batin",
                    )],
                )

        custom = AnalyzerRegistry()
        custom.register(ScanErrorAnalyzer)
        report = ScanService(registry=custom).scan(CLEAN_PDF)
        assert report.scan_incomplete is True
        assert report.integrity_score <= 0.5


# ---------------------------------------------------------------------------
# Additive isolation — ScanService is distinct from v0.1
# ---------------------------------------------------------------------------

class TestAdditiveIsolation:
    def test_scan_service_class_distinct_from_v01(self) -> None:
        """The new class must not be the legacy class. If they became the
        same object, we would have accidentally re-bound v0.1's export."""
        assert ScanService is not bayyinah_v0_1.ScanService

    def test_legacy_scan_pdf_still_works(self) -> None:
        """v0.1's public surface must still produce a report — the
        Phase 6 port must not have broken it."""
        report = bayyinah_v0_1.scan_pdf(CLEAN_PDF)
        assert isinstance(report.findings, list)
        assert report.integrity_score == 1.0

    def test_default_pdf_registry_returns_new_instance_per_call(self) -> None:
        """Independence requirement for parallel tests / parallel scans."""
        a = default_pdf_registry()
        b = default_pdf_registry()
        assert a is not b


# ---------------------------------------------------------------------------
# Resource hygiene
# ---------------------------------------------------------------------------

class TestResourceHygiene:
    def test_repeated_scans_on_same_service(self) -> None:
        """The service must be reusable across many scans — no lingering
        state from a previous file."""
        service = ScanService()
        for _ in range(5):
            report = service.scan(CLEAN_PDF)
            assert report.integrity_score == 1.0
            assert report.error is None

    def test_repeated_scans_on_different_fixtures(self) -> None:
        service = ScanService()
        for pdf in _all_phase0_fixtures():
            report = service.scan(pdf)
            assert isinstance(report, IntegrityReport)
