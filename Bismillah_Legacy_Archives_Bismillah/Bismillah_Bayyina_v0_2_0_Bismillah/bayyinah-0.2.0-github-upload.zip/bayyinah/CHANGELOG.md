# Changelog

All notable changes to Bayyinah are documented here. Format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/); versioning follows
[SemVer](https://semver.org/spec/v2.0.0.html).

The modular refactor of 0.2.0 was organised as the eight-phase Al-Baqarah
roadmap. Each phase added one architectural slice behind the existing
reference implementation without touching it — the parity invariant
(`bayyinah.scan_pdf == bayyinah_v0.scan_pdf` on every Phase 0 fixture) has
held across every phase.

## [0.2.0] — 2026-04-22

### Added

- **Public Python API** (`bayyinah/__init__.py`). `from bayyinah import
  scan_pdf` is now the canonical entry point. Re-exports the orchestrator,
  analyzers, formatters, and domain types.
- **CLI** (`cli/main.py`) with subcommand surface:
  `bayyinah scan <file> [--json | --summary | --quiet]`. Exit codes
  preserved byte-for-byte from v0/v0.1 (0 / 1 / 2 for clean / findings /
  error). `bayyinah --version` added.
- **Domain layer** (`domain/`). Pure data types and scoring primitives —
  `Finding`, `IntegrityReport`, `compute_muwazana_score`, `tamyiz_verdict`,
  `apply_scan_incomplete_clamp`, `BayyinahError` hierarchy. No I/O, no
  parser dependencies.
- **Infrastructure layer** (`infrastructure/`). `PDFClient` wraps the
  pymupdf + pypdf handles with context-manager safety. `FileRouter`
  detects PDF / DOCX / HTML / JSON / image / code by magic bytes and
  extension, flags polyglot files. `TerminalReportFormatter`,
  `JsonReportFormatter`, `PlainLanguageFormatter` — all byte-identical to
  v0.1's inline `format_text_report` / `plain_language_summary`.
- **Analyzer layer** (`analyzers/`). `BaseAnalyzer` contract enforces a
  uniform per-analyzer `IntegrityReport` shape. `ZahirTextAnalyzer` and
  `BatinObjectAnalyzer` port every detection mechanism from v0.1.
  `AnalyzerRegistry` composes registered analyzers into one merged report
  with the `scan_incomplete` clamp applied post-merge.
- **Application layer** (`application/`). `ScanService` orchestrator:
  file-exists short-circuit → pymupdf preflight → dispatch to the
  registry. Byte-identical behaviour to `bayyinah_v0_1.scan_pdf` across
  every Phase 0 fixture.
- **Test corpus**. 500+ pytest cases across domain, infrastructure,
  analyzers, application, and integration suites. Every Phase 0 fixture
  is asserted for exact mechanism firings, score, error text, and
  scan_incomplete flag against both v0 and v0.1.

### Changed

- `[project.scripts] bayyinah` now points to `cli.main:main` (was
  `bayyinah_v0_1:main`). The `bayyinah_v0` and `bayyinah_v0_1` module-level
  `main` functions remain callable for downstream pins.

### Preserved (Additive-Only Invariant)

- `bayyinah_v0.py` and `bayyinah_v0_1.py` are unchanged. Both remain in
  the wheel as reference implementations. No line was added, removed, or
  modified in either file during the 0.2.0 refactor. Module mtimes
  verified after each phase.

### Architectural References

- [Munafiq Protocol — Detecting Performed Alignment in Artificial
  Systems](https://doi.org/10.5281/zenodo.19677111) (DOI:
  10.5281/zenodo.19677111). The scanner's scoring model (APS-continuous,
  three validity tiers, tamyiz verdict) is a direct port of §9's
  input-layer framing from LLMs to files.
- Internal roadmap: `NAMING.md` captures the Al-Baqarah phase mapping.

## [0.1.0] — 2026-04-22

### Added

- `bayyinah_v0.py` — the original monolithic scanner. Detects:
  - Text-layer mechanisms: `zero_width_chars`, `tag_chars`, `bidi_control`,
    `homoglyph`, `invisible_render_mode`, `microscopic_font`,
    `white_on_white_text`, `overlapping_text`.
  - Object-layer mechanisms: `javascript`, `openaction`,
    `additional_actions`, `launch_action`, `embedded_file`,
    `file_attachment_annot`, `incremental_update`, `metadata_anomaly`,
    `hidden_ocg`, `tounicode_anomaly`.
- `bayyinah_v0_1.py` — fat-split intermediate introducing `PDFContext`,
  `BaseAnalyzer`, `TextLayerAnalyzer`, `ObjectLayerAnalyzer`,
  `ScanService`. Byte-identical output to v0 across the fixture corpus.
- Phase 0 fixture corpus (`tests/fixtures/`): `clean.pdf`,
  `positive_combined.pdf`, 8 text-layer fixtures, 7 object-layer fixtures.
  Each fires exactly its declared mechanism set under v0.

---

**License:** Apache-2.0. See `LICENSE` for the full text. Anthropic's
usage-policies apply when running Bayyinah as an agent tool; see
project README.
