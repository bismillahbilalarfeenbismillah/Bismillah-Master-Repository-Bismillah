"""
Bayyinah domain layer.

Pure data types and pure operations. No I/O, no parser dependencies,
no global state. This package is the language in which the rest of
Bayyinah describes what it found — analyzers build ``Finding`` objects,
the scan service assembles them into an ``IntegrityReport``, the
reporting layer reads the report and renders it.

Phase 1 of the Al-Baqarah refactor. Additive-only: the legacy
``bayyinah_v0`` and ``bayyinah_v0_1`` modules continue to define their
own internal Finding / IntegrityReport shapes until later phases
migrate the analyzers onto this domain contract.
"""

from __future__ import annotations

from domain.config import (
    BATIN_MECHANISMS,
    CONFUSABLE_TO_LATIN,
    SEVERITY,
    TIER,
    TIER_LEGEND,
    TOOL_NAME,
    TOOL_VERSION,
    VERDICT_DISCLAIMER,
    VERDICT_MUGHLAQ,
    VERDICT_MUKHFI,
    VERDICT_MUNAFIQ,
    VERDICT_MUSHTABIH,
    VERDICT_SAHIH,
    ZAHIR_MECHANISMS,
    SourceLayer,
    Verdict,
)
from domain.exceptions import (
    BayyinahError,
    InvalidFindingError,
    PDFParseError,
    ScanError,
)
from domain.finding import Finding
from domain.integrity_report import IntegrityReport
from domain.value_objects import (
    apply_scan_incomplete_clamp,
    compute_muwazana_score,
    tamyiz_verdict,
)

__all__ = [
    # Dataclasses
    "Finding",
    "IntegrityReport",
    # Pure functions
    "compute_muwazana_score",
    "tamyiz_verdict",
    "apply_scan_incomplete_clamp",
    # Exceptions
    "BayyinahError",
    "InvalidFindingError",
    "PDFParseError",
    "ScanError",
    # Config — most frequently imported members
    "SEVERITY",
    "TIER",
    "TIER_LEGEND",
    "VERDICT_DISCLAIMER",
    "TOOL_NAME",
    "TOOL_VERSION",
    "ZAHIR_MECHANISMS",
    "BATIN_MECHANISMS",
    "CONFUSABLE_TO_LATIN",
    "SourceLayer",
    "Verdict",
    "VERDICT_SAHIH",
    "VERDICT_MUSHTABIH",
    "VERDICT_MUKHFI",
    "VERDICT_MUNAFIQ",
    "VERDICT_MUGHLAQ",
]
