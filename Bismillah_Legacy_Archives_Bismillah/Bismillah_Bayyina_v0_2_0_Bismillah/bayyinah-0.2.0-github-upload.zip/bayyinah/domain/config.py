"""
Domain configuration — constants that govern Bayyinah's detector semantics.

This module centralises every tunable threshold, character set, severity
weight, and validity tier that the detectors consume. It is the single
source of truth for the *shape* of what Bayyinah considers concealment.

Conceptual grounding (Al-Baqarah 2:8-10, Munafiq Protocol §9):
The munafiq (hypocrite) is defined by the gap between the *zahir* (the
outward / apparent layer — what the observer perceives) and the *batin*
(the inner / hidden layer — what is actually carried). Bayyinah's
detector surface inherits this distinction. Every mechanism is labelled
either zahir — a concealment that lives in the rendered/textual surface
a human reader sees — or batin — a concealment hidden in the document's
inner object graph (catalog actions, embedded files, font CMaps,
metadata, incremental saves).

This file introduces no runtime behaviour — it only exposes the
constants used by the domain dataclasses and by any future analyzer that
binds to the domain layer. Values here mirror ``bayyinah_v0.py`` /
``bayyinah_v0_1.py`` exactly; nothing is altered. This is the "additive
only" invariant of Phase 1.
"""

from __future__ import annotations

from typing import Final, Literal


# ---------------------------------------------------------------------------
# Source layer classification (zahir / batin)
# ---------------------------------------------------------------------------

SourceLayer = Literal["zahir", "batin"]
"""Type alias for the two concealment-locus layers.

zahir — surface / textual / rendered layer. A reader sees the document
and the mechanism's *effect* is in that surface (or suppressed from it).
batin — inner / structural / object layer. The mechanism lives in the
PDF's catalog, action tree, embedded files, fonts, or incremental
saves — places a normal reader never consults.
"""

# Mechanisms whose concealment manifests in the textual/rendered surface.
ZAHIR_MECHANISMS: Final[frozenset[str]] = frozenset({
    "invisible_render_mode",
    "white_on_white_text",
    "microscopic_font",
    "off_page_text",
    "zero_width_chars",
    "bidi_control",
    "tag_chars",
    "overlapping_text",
    "homoglyph",
})

# Mechanisms whose concealment lives in the document's inner object graph.
BATIN_MECHANISMS: Final[frozenset[str]] = frozenset({
    "javascript",
    "openaction",
    "additional_actions",
    "launch_action",
    "embedded_file",
    "file_attachment_annot",
    "incremental_update",
    "metadata_anomaly",
    "hidden_ocg",
    "tounicode_anomaly",
    # scan_error is a meta-mechanism — the scan itself did not complete.
    # It is structural (not visible to the reader) and so is catalogued
    # under batin, consistent with "the inner state was not fully
    # inspected".
    "scan_error",
})


# ---------------------------------------------------------------------------
# Unicode character sets (used by zahir-layer analyzers)
# ---------------------------------------------------------------------------

ZERO_WIDTH_CHARS: Final[frozenset[str]] = frozenset([
    "\u200B",  # ZWSP
    "\u200C",  # ZWNJ
    "\u200D",  # ZWJ
    "\u2060",  # WORD JOINER
    "\uFEFF",  # BOM / ZWNBSP
])

BIDI_CONTROL_CHARS: Final[frozenset[str]] = frozenset([
    "\u202A", "\u202B", "\u202C", "\u202D", "\u202E",  # embedding / override
    "\u2066", "\u2067", "\u2068", "\u2069",            # isolates
])

# Unicode TAG block — smuggling vector for model input pipelines.
TAG_CHAR_RANGE: Final[range] = range(0xE0000, 0xE0080)

# Curated confusables — lookalike codepoint -> Latin glyph it imitates.
# Biased toward letters with high impersonation value (phishing, prompt
# injection). This is a subset of the Unicode Consortium's confusables.txt.
CONFUSABLE_TO_LATIN: Final[dict[str, str]] = {
    # Cyrillic
    "\u0430": "a", "\u0435": "e", "\u043E": "o", "\u0440": "p",
    "\u0441": "c", "\u0443": "y", "\u0445": "x", "\u0456": "i",
    "\u0458": "j", "\u0455": "s",
    "\u0410": "A", "\u0412": "B", "\u0415": "E", "\u041A": "K",
    "\u041C": "M", "\u041D": "H", "\u041E": "O", "\u0420": "P",
    "\u0421": "C", "\u0422": "T", "\u0425": "X", "\u0406": "I",
    # Greek
    "\u03B1": "a", "\u03BF": "o", "\u03BD": "v", "\u03C1": "p",
    "\u03C5": "u", "\u0391": "A", "\u0392": "B", "\u0395": "E",
    "\u0397": "H", "\u0399": "I", "\u039A": "K", "\u039C": "M",
    "\u039D": "N", "\u039F": "O", "\u03A1": "P", "\u03A4": "T",
    "\u03A7": "X", "\u03A5": "Y", "\u0396": "Z",
    # Armenian / Cherokee that hit common Latin targets
    "\u0578": "n", "\u0585": "o",
    "\u13A0": "D", "\u13AC": "T", "\u13A2": "R", "\u13C4": "V",
    # Latin fullwidth (mostly seen in e-mail spam)
    "\uFF41": "a", "\uFF45": "e", "\uFF4F": "o", "\uFF50": "p",
    # Mathematical alphanumerics (frequent in prompt-injection attempts)
    "\U0001D41A": "a", "\U0001D41E": "e", "\U0001D428": "o",
}


# ---------------------------------------------------------------------------
# Physics / rendering thresholds (used by zahir-layer analyzers)
# ---------------------------------------------------------------------------

# PDF text render-mode 3 = "invisible" — glyph is advanced but not filled
# or stroked. Present in the text layer, absent from the visual rendering.
INVISIBLE_RENDER_MODE: Final[int] = 3

# Font size (in PDF points) below which text is considered sub-visual.
MICROSCOPIC_FONT_THRESHOLD: Final[float] = 1.0

# Luminance of a pure-white page background (sRGB max).
BACKGROUND_LUMINANCE_WHITE: Final[float] = 1.0

# Delta-luminance below which text blends with a white background.
COLOR_CONTRAST_THRESHOLD: Final[float] = 0.05

# Span-bbox IoU above which two overlapping text spans are flagged as
# stacked concealment.
SPAN_OVERLAP_THRESHOLD: Final[float] = 0.5


# ---------------------------------------------------------------------------
# APS-style severity weights
# ---------------------------------------------------------------------------
# How much each mechanism subtracts from the base integrity score of 1.0.
# Continuous contribution, not a binary verdict.

SEVERITY: Final[dict[str, float]] = {
    # Text layer (zahir)
    "invisible_render_mode": 0.25,
    "white_on_white_text":   0.20,
    "microscopic_font":      0.10,
    "off_page_text":         0.15,
    "zero_width_chars":      0.10,
    "bidi_control":          0.15,
    "tag_chars":             0.30,
    "overlapping_text":      0.25,
    "homoglyph":             0.20,
    # Object layer (batin)
    "javascript":            0.30,
    "openaction":            0.15,
    "additional_actions":    0.15,
    "launch_action":         0.25,
    "embedded_file":         0.25,
    "file_attachment_annot": 0.20,
    "incremental_update":    0.05,
    "metadata_anomaly":      0.05,
    "hidden_ocg":            0.15,
    "tounicode_anomaly":     0.30,
    "scan_error":            0.00,  # reported but does not deduct
}

# Default severity for any unknown mechanism — mirrors v0 behaviour.
DEFAULT_SEVERITY: Final[float] = 0.05


# ---------------------------------------------------------------------------
# Validity tier by mechanism
# ---------------------------------------------------------------------------
# 1 — Verified: mechanism unambiguously identifiable; presence = concealment
# 2 — Structural: pattern of concealment, could be benign in rare cases
# 3 — Interpretive: suspicious, heavily context-dependent

TIER: Final[dict[str, int]] = {
    "invisible_render_mode": 1,
    "white_on_white_text":   1,
    "microscopic_font":      2,
    "off_page_text":         2,
    "zero_width_chars":      2,
    "bidi_control":          2,
    "tag_chars":             1,
    "overlapping_text":      2,
    "homoglyph":             2,
    "javascript":            1,
    "openaction":            2,
    "additional_actions":    2,
    "launch_action":         1,
    "embedded_file":         2,
    "file_attachment_annot": 2,
    "incremental_update":    3,
    "metadata_anomaly":      3,
    "hidden_ocg":            2,
    "tounicode_anomaly":     1,
    "scan_error":            3,
}


# ---------------------------------------------------------------------------
# Scan-incomplete clamp
# ---------------------------------------------------------------------------

# When the scan did not fully cover the document (scanner error, or any
# finding with mechanism == scan_error), clamp the integrity score to at
# most this value. Absence of findings in an uninspected region cannot be
# taken as evidence of cleanness.
SCAN_INCOMPLETE_CLAMP: Final[float] = 0.5


# ---------------------------------------------------------------------------
# Verdict labels (tamyiz)
# ---------------------------------------------------------------------------

Verdict = Literal["sahih", "mushtabih", "mukhfi", "munafiq", "mughlaq"]
"""Verdict labels used by ``tamyiz_verdict``.

sahih      — sound; score == 1.0, no findings, scan complete.
mushtabih  — suspicious; score in [0.7, 1.0), some concealment signal
             but nothing verified unambiguously.
mukhfi     — concealment detected; score in [0.3, 0.7).
munafiq    — severe concealment; score < 0.3 AND at least one tier-1
             finding (verified concealment mechanism present).
mughlaq    — closed / withheld; scan_incomplete is true or an error
             occurred, no verdict can be issued from an unfinished scan.

NB: These labels classify the *report*, not the document's author or
intent. Bayyinah surfaces the gap between surface and content; it does
not self-validate a moral judgement. The reader performs the recognition.
"""

VERDICT_SAHIH: Final[Verdict] = "sahih"
VERDICT_MUSHTABIH: Final[Verdict] = "mushtabih"
VERDICT_MUKHFI: Final[Verdict] = "mukhfi"
VERDICT_MUNAFIQ: Final[Verdict] = "munafiq"
VERDICT_MUGHLAQ: Final[Verdict] = "mughlaq"


# ---------------------------------------------------------------------------
# Tier legend — exposed verbatim in IntegrityReport.to_dict output.
# ---------------------------------------------------------------------------

TIER_LEGEND: Final[dict[str, str]] = {
    "1": "Verified — unambiguous concealment",
    "2": "Structural — pattern of concealment, context may justify",
    "3": "Interpretive — suspicious, context-dependent",
}

# Verbatim disclaimer exposed in IntegrityReport.to_dict output.
VERDICT_DISCLAIMER: Final[str] = (
    "This report presents observed mechanisms and their validity tiers. "
    "It does NOT self-validate a moral or malicious verdict. The scanner "
    "makes the invisible visible; the reader performs the recognition."
)


# ---------------------------------------------------------------------------
# Tool identity — reproduced in IntegrityReport.to_dict output.
# ---------------------------------------------------------------------------

TOOL_NAME: Final[str] = "bayyinah"
TOOL_VERSION: Final[str] = "0.1.0"


__all__ = [
    "SourceLayer",
    "ZAHIR_MECHANISMS",
    "BATIN_MECHANISMS",
    "ZERO_WIDTH_CHARS",
    "BIDI_CONTROL_CHARS",
    "TAG_CHAR_RANGE",
    "CONFUSABLE_TO_LATIN",
    "INVISIBLE_RENDER_MODE",
    "MICROSCOPIC_FONT_THRESHOLD",
    "BACKGROUND_LUMINANCE_WHITE",
    "COLOR_CONTRAST_THRESHOLD",
    "SPAN_OVERLAP_THRESHOLD",
    "SEVERITY",
    "DEFAULT_SEVERITY",
    "TIER",
    "SCAN_INCOMPLETE_CLAMP",
    "Verdict",
    "VERDICT_SAHIH",
    "VERDICT_MUSHTABIH",
    "VERDICT_MUKHFI",
    "VERDICT_MUNAFIQ",
    "VERDICT_MUGHLAQ",
    "TIER_LEGEND",
    "VERDICT_DISCLAIMER",
    "TOOL_NAME",
    "TOOL_VERSION",
]
