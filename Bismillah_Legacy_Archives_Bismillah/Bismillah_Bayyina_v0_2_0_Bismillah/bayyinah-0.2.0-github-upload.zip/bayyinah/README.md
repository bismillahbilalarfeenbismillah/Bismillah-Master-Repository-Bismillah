# Bayyinah

**File integrity scanner for detecting hidden, concealed, or adversarial content in digital documents.**

Bayyinah extracts every content layer from a file — visible and invisible — and reports whether what the file *displays* matches what the file *contains*. It is the input-layer application of the [Munafiq Protocol](https://doi.org/10.5281/zenodo.19677111)'s performed-alignment detection: a document that renders cleanly at the surface while carrying concealed payloads, steganographic encoding, embedded prompt injections, or cross-modal anomalies is a document performing alignment. Bayyinah makes the performance visible; the reader performs the recognition.

[![License: Apache 2.0](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](https://www.apache.org/licenses/LICENSE-2.0)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![DOI](https://img.shields.io/badge/DOI-10.5281%2Fzenodo.19677111-blue)](https://doi.org/10.5281/zenodo.19677111)

## What Bayyinah detects

Two concealment *loci*, mapped onto the classical distinction between *zahir* (the outward / rendered) and *batin* (the inner / structural):

**Zahir — text layer (what the reader sees vs. what the parser extracts)**
- Zero-width characters, Unicode TAG characters (U+E0000–U+E007F), bidirectional-control overrides, homoglyph / mixed-script substitution, invisible render modes (3, 7), microscopic fonts, white-on-white text, overlapping / stacked text.

**Batin — object layer (what ships inside the PDF's object graph)**
- Embedded JavaScript, `/OpenAction`, `/AA` additional actions, `/Launch` actions, embedded files and FileAttachment annotations, incremental updates (prior revisions still present), metadata anomalies (ModDate preceding CreationDate), hidden Optional Content Groups, adversarial `/ToUnicode` CMaps mapping visible glyphs to zero-width, bidi, TAG, or homoglyph codepoints.

Supported inputs today: **PDF**. Detection for DOCX, HTML, Markdown, JSON, images, and code files is on the roadmap; the file router already classifies them, so polyglot mismatches (e.g. a `.pdf` whose bytes are really ZIP) already surface.

## Install

```bash
pip install bayyinah
```

Or from source:

```bash
git clone https://github.com/doctordopemusic/bayyinah.git
cd bayyinah
pip install -e '.[dev]'
```

Runtime dependencies: `pymupdf>=1.24`, `pypdf>=4.0`. Python 3.10 or newer.

## Quick test

After installation, verify the scanner is wired up correctly by pointing it at the bundled reference fixture:

```bash
bayyinah scan tests/fixtures/clean.pdf
# → Integrity score: 1.000 / 1.000. No concealment mechanisms detected.

bayyinah scan tests/fixtures/text/zero_width.pdf
# → Integrity score: 0.915 / 1.000. 1 finding: zero_width_chars (tier 1).
```

Exit code convention (stable across versions, CI-safe):

| Code | Meaning |
|------|---------|
| `0`  | Scan completed; zero findings |
| `1`  | Scan completed; one or more findings |
| `2`  | Scan did not complete (file missing, unparseable, …) |

## CLI usage

```
bayyinah scan <file>                    # human-readable report
bayyinah scan <file> --json             # JSON report on stdout
bayyinah scan <file> --summary          # one-paragraph plain-language summary
bayyinah scan <file> --quiet            # suppress output; exit code only
bayyinah --version
bayyinah --help
```

A CI pipeline that wants to fail any build whose dependency PDF carries concealment mechanisms can write:

```bash
bayyinah scan release_notes.pdf --quiet || {
  echo "release_notes.pdf failed integrity scan"
  exit 1
}
```

## Python API

```python
from bayyinah import scan_pdf, format_text_report

report = scan_pdf("document.pdf")

print(report.integrity_score)           # 0.873
print([f.mechanism for f in report.findings])
# ['additional_actions']

print(format_text_report(report))       # full terminal report
```

Building a custom analyzer pipeline:

```python
from bayyinah import ScanService, AnalyzerRegistry, ZahirTextAnalyzer

registry = AnalyzerRegistry()
registry.register(ZahirTextAnalyzer)   # text-layer only

report = ScanService(registry=registry).scan("document.pdf")
```

Writing a new analyzer:

```python
from bayyinah import BaseAnalyzer, Finding, IntegrityReport, compute_muwazana_score

class MyAnalyzer(BaseAnalyzer):
    name = "my_analyzer"
    error_prefix = "My analyzer error"
    source_layer = "batin"   # or "zahir"

    def scan(self, pdf_path):
        findings = []  # populate from your detection pass
        return IntegrityReport(
            file_path=str(pdf_path),
            integrity_score=compute_muwazana_score(findings),
            findings=findings,
        )
```

## Scoring model

Bayyinah reports an **APS-continuous integrity score** on `[0.0, 1.0]`:

```
score = clamp(1.0 − Σ(severity × confidence), 0, 1)
```

Each finding contributes a continuous deduction proportional to the concealment mass it represents (severity) scaled by the detector's confidence it fired correctly. The score saturates at `0.0`; it does not go negative. Whenever any analyzer reports incomplete coverage, the score is clamped to `0.5` — the reader cannot infer cleanness from the absence of findings in regions that were not inspected.

Every finding carries one of three validity tiers:

- **Tier 1 — verified.** Unambiguous concealment (TAG characters present; a `/JS` action in the catalog). Machine-checkable.
- **Tier 2 — structural.** A structural anomaly whose meaning depends on context (a font ToUnicode CMap that maps to a zero-width codepoint is concealment; mapped to a Latin homoglyph it is deception, but the CMap itself is structural).
- **Tier 3 — interpretive.** The signal is present but its interpretation rests on the reader (an incremental-update trail is not itself adversarial; the question is what the prior revision contained).

The scanner never issues a moral verdict on its own. It surfaces mechanisms. The reader performs the recognition.

## Architecture

Bayyinah 0.2.0 is organised as the *middle community* (Al-Baqarah 2:143) of cooperating layers — each analyzer applies the same standard and reports in the same shape:

```
bayyinah/                public Python API (scan_pdf, ScanService, …)
cli/                     console script (bayyinah CLI)
application/             ScanService orchestrator
analyzers/               BaseAnalyzer contract + Zahir/Batin analyzers
infrastructure/          PDFClient, FileRouter, formatters
domain/                  pure Finding / IntegrityReport / scoring
```

The reference implementation is preserved unchanged at `bayyinah_v0.py` and its fat-split intermediate at `bayyinah_v0_1.py`; both ship in the wheel. The parity invariant — `bayyinah.scan_pdf == bayyinah_v0.scan_pdf` on every Phase 0 fixture — is asserted by the integration test suite and held across the full modular refactor.

## Development

```bash
# Install with dev extras
pip install -e '.[dev]'

# Generate fixture corpus (one-time)
python -m tests.make_test_documents

# Run the full suite
pytest

# Scan a file directly from source tree
python -m cli.main scan path/to/file.pdf
```

500+ pytest cases. Every Phase 0 fixture is asserted for exact mechanism firings, score, error text, and scan_incomplete flag — against both v0 and v0.1.

## Academic reference

If you use Bayyinah in published work, please cite the underlying protocol:

> **Munafiq Protocol — Detecting Performed Alignment in Artificial Systems.**
> DOI: [10.5281/zenodo.19677111](https://doi.org/10.5281/zenodo.19677111)

The scanner's scoring model, validity tiers, and verdict taxonomy (*sahih*, *mushtabih*, *mukhfi*, *munafiq*, *mughlaq*) are a direct port of §9's input-layer framing from LLMs to files.

## License

Apache 2.0. See [LICENSE](LICENSE) for full text and [CHANGELOG.md](CHANGELOG.md) for version history.

---

*Bayyinah* (بَيِّنَة) — "clear evidence."
